package com.real.android_project_second;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class joinActivity extends AppCompatActivity  implements View.OnClickListener {

    EditText etId;
    EditText etPw;
    EditText etPwRe;
    EditText etName;

    Button btSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        etId = findViewById(R.id.et_id);
        etPw = findViewById(R.id.et_pw);
        etPwRe = findViewById(R.id.et_pw_re);
        etName = findViewById(R.id.et_name);

        btSubmit = findViewById(R.id.bt_join_submit);

        btSubmit.setOnClickListener(this);

    }

    public boolean pwd_check(){
        boolean check=true;

        if(!etPw.getText().toString().trim().equals(etPwRe.getText().toString().trim())){

            check = false;

        }
        return check;

    }


    public boolean checkBlank(){

        boolean check=true;

        if(etId.getText().toString().trim().length()<1){
            check=false;
        }
        else if(etPw.getText().toString().trim().length()<1){
            check=false;
        }
        else if(etName.getText().toString().trim().length()<1){
            check=false;
        }
        else if(etPwRe.getText().toString().trim().length()<1){
            check=false;
        }

        return check;

    }


    @Override
    public void onClick(View v) {

        if(pwd_check()){
            if(checkBlank()){

                /** post **/
                RequestQueue stringRequest = Volley.newRequestQueue(this);
                String url = ipToken.ipToken+"myAndroid_server/joinServlet_url";

                StringRequest myReq = new StringRequest(Request.Method.POST, url,
                        successListener, errorListener) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();

                        String id = etId.getText().toString().trim();
                        String pw = etPw.getText().toString().trim();
                        String name = etName.getText().toString().trim();

                        Log.d("aa","id "+id);
                        Log.d("aa","pw "+pw);
                        Log.d("aa","name "+name);

                        params.put("input_id", id);
                        params.put("input_pwd", pw);
                        params.put("input_name", name);

                        return params;
                    }
                };
                myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
                );
                stringRequest.add(myReq);

            }

            else{

                AlertDialog.Builder builder = new AlertDialog.Builder(joinActivity.this);

                builder.setTitle("아이디 중복").setMessage("아이디가 중복됩니다.");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_SHORT).show();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();


            }

        }
        else{

            AlertDialog.Builder builder = new AlertDialog.Builder(joinActivity.this);

            builder.setTitle("비밀번호 확인").setMessage("비밀번호가 일치하지 않습니다");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int id)
                {
                    Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_SHORT).show();
                }
            });

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

    }

    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "통신성공");

            try {
                JSONObject jObject = new JSONObject(response);
                Log.d("aa",">>"+jObject.getString("result"));
                String result= jObject.getString("result");
                if(result.equals("OK")){
                    Intent intent =new Intent(joinActivity.this,com.real.android_project_second.MainActivity.class);
                    startActivity(intent);

                    finish();
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(joinActivity.this);

                    builder.setTitle("아이디 중복").setMessage("아이디가 중복됩니다.");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int id)
                        {
                            Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_SHORT).show();
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    };
}