package com.real.android_project_second;

public class ipToken {
    public static String ipToken="http://192.168.0.6:8080/";
}
