package com.real.android_project_second;

public class productData {

    String idx;
    String product_name;
    String product_price;
    String product_img;

    public productData(String idx, String product_name, String product_price, String product_img) {

        this.idx = idx;
        this.product_name = product_name;
        this.product_price = product_price;
        this.product_img = product_img;
    }

}
