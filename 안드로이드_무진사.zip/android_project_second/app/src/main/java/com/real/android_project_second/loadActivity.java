package com.real.android_project_second;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;

public class loadActivity extends AppCompatActivity {

    int value = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load);
        handler.sendEmptyMessageDelayed(0, 1000);
    }


    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            /*          int what = msg.what;*/
            value++;

            if(value < 2){
                handler.sendEmptyMessageDelayed(0, 1000);
            }
            else if(value==2){
                handler.removeMessages(0);

                Intent intent = new Intent(loadActivity.this,com.real.android_project_second.MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    };
}