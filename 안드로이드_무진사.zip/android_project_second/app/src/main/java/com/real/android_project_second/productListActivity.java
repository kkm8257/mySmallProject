package com.real.android_project_second;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class productListActivity extends AppCompatActivity {

    ListView product_list_view;
    String kinds;
    String path=ipToken.ipToken+"myAndroid_server/storage/";
    MyAdapter adapter;
    ArrayList<productData> productList = new ArrayList<>();

    Button btn_my_info;
    Button btn_my_cart;
    ProgressBar pgbar;

    String token=loginToken.token;

    //로딩 제어
    int value=0;
    boolean newLoadChk=true;
    ////////////////////
    boolean lastitemVisibleFlag;


    int click_value=0;
    boolean clickAllow=true;
    boolean newLoadChk_click=true;

    Intent intent_product;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        pgbar=findViewById(R.id.pgbar);


        btn_my_info=findViewById(R.id.btn_my_info);
        btn_my_cart=findViewById(R.id.btn_my_cart);

        int pgbColor = getResources().getColor(R.color.black_500);
        pgbar.setIndeterminate(true);
        pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);


        btn_my_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent intent = new Intent(productListActivity.this,com.real.android_project_second.myinfo.class);
                startActivity(intent);

            }
        });

        btn_my_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(productListActivity.this,com.real.android_project_second.cartListActivity.class);
                startActivity(intent);

            }
        });

        product_list_view=findViewById(R.id.product_list_view);
        Intent intent = getIntent();
        kinds=intent.getStringExtra("kind");
        path=path+kinds+"/";
        init();

        adapter = new MyAdapter(this);
        product_list_view.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        lastitemVisibleFlag = false;        //화면에 리스트의 마지막 아이템이 보여지는지 체크

        product_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(clickAllow){

                    handler_click.sendEmptyMessageDelayed(0, 1000);
                    intent_product   = new Intent(productListActivity.this,com.real.android_project_second.productInfo.class);
                    intent_product.putExtra("kind", kinds);
                    intent_product.putExtra("row", Integer.toString(position));
                    clickAllow=false;
                }


            }
        });

        product_list_view.setOnScrollListener(new AbsListView.OnScrollListener() {

            int RowNum;

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                //현재 화면에 보이는 첫번째 리스트 아이템의 번호(firstVisibleItem) + 현재 화면에 보이는 리스트 아이템의 갯수(visibleItemCount)가 리스트 전체의 갯수(totalItemCount) -1 보다 크거나 같을때
                lastitemVisibleFlag = (totalItemCount > 0) && (firstVisibleItem + visibleItemCount >= totalItemCount);
                RowNum=totalItemCount;
            }
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                //OnScrollListener.SCROLL_STATE_IDLE은 스크롤이 이동하다가 멈추었을때 발생되는 스크롤 상태입니다.
                //즉 스크롤이 바닦에 닿아 멈춘 상태에 처리를 하겠다는 뜻
                if(scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE && lastitemVisibleFlag) {
                    //TODO 화면이 바닦에 닿을때 처리
                    if(newLoadChk){
                        pgbar.setVisibility(View.VISIBLE);
                        newLoadChk=false;
                        handler.sendEmptyMessageDelayed(0,1000);
                        Log.d("aa","화면끝");
                        Log.d("aa","row_num >>"+RowNum);
                        request(RowNum);

                    }


                }
            }

        });




    }

    /////////////////////////////////////////////////////////////////////////////////////////

    public void init(){
        //product kinds로 참조
        /** post **/
        RequestQueue stringRequest = Volley.newRequestQueue(this);
        String url = ipToken.ipToken+"myAndroid_server/productInitService_url";

        StringRequest myReq = new StringRequest(Request.Method.POST, url,
                successListener_init, errorListener_init) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                Log.d("aa","request kinds >>"+kinds);
                params.put("kinds", kinds);
                params.put("token",token);

                return params;
            }
        };
        myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
        );
        stringRequest.add(myReq);

    }

    Response.ErrorListener errorListener_init = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_init = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "init() 통신성공");

            try {
                JSONObject jObject = new JSONObject(response);
                int kinds_length=Integer.parseInt(jObject.getString("kinds_length"));
//                Log.d("aa",">>>>>"+kinds_length);
//                Log.d("aa","res : "+response);


                if(kinds_length<=4){

                    for(int i = 0 ; i <kinds_length ; i++ ){

                        String name="product_name_"+Integer.toString(i);
                        String price="product_price_"+Integer.toString(i);
                        String img="product_img_"+Integer.toString(i);

                        Log.d("aa",">>"+img);

                        productList.add(new productData(Integer.toString(i),jObject.getString(name),jObject.getString(price),jObject.getString(img)));
                        adapter.notifyDataSetChanged();
                    }
                }
                else if(kinds_length>4){

                    for(int i = 0 ; i <4 ; i++ ){

                        String name="product_name_"+Integer.toString(i);
                        String price="product_price_"+Integer.toString(i);
                        String img="product_img_"+Integer.toString(i);

                        Log.d("aa",">>"+img);

                        productList.add(new productData(Integer.toString(i),jObject.getString(name),jObject.getString(price),jObject.getString(img)));
                        adapter.notifyDataSetChanged();
                    }
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };




///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    class productHolder{

        ImageView custom_product_img_holder;
        TextView custom_product_name_holder;
        TextView custom_product_price_holder;
    }

    class MyAdapter extends ArrayAdapter {
        LayoutInflater lnf;

        public MyAdapter(Activity context) {
            super(context, R.layout.activity_custom_product_item, productList);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return productList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return productList.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            productHolder viewHolder;
            if (convertView == null) {

                convertView = lnf.inflate(R.layout.activity_custom_product_item, parent, false);
                viewHolder = new productHolder();

                viewHolder.custom_product_img_holder = convertView.findViewById(R.id.custom_product_img);
                viewHolder.custom_product_name_holder = convertView.findViewById(R.id.custom_product_name);
                viewHolder.custom_product_price_holder = convertView.findViewById(R.id.custom_product_price);

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (productHolder) convertView.getTag();
            }

            Glide.with(productListActivity.this).load(productList.get(position).product_img).into(viewHolder.custom_product_img_holder);
            Log.d("aa","268번째 쭐 : " + productList.get(position).product_img);
            viewHolder.custom_product_name_holder.setText(productList.get(position).product_name);
            viewHolder.custom_product_price_holder.setText(productList.get(position).product_price);

            return convertView;
        }
    }
////////////////////////////////////////////////////////////
   public void request(int totalItemCount){
        //product kinds로 참조
       /** post **/
       RequestQueue stringRequest = Volley.newRequestQueue(this);
       String url = ipToken.ipToken+"myAndroid_server/productListService_url";

       StringRequest myReq = new StringRequest(Request.Method.POST, url,
               successListener, errorListener) {
           @Override
           protected Map<String, String> getParams() throws AuthFailureError {
               Map<String, String> params = new HashMap<String, String>();
                Log.d("aa","request kinds >>"+kinds);

               params.put("kinds", kinds);
               params.put("row_num",Integer.toString(totalItemCount));

               return params;
           }
       };
       myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 1, 1f)
       );
       stringRequest.add(myReq);
        
   }

    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "통신성공");

            try {
                JSONObject jObject = new JSONObject(response);
                String result= jObject.getString("result");

                Log.d("aa","result >>"+result);

                //Log.d("aa","이제 보여줄 row >>"+jObject.getString("new_row_num"));

                if(result.equals("OK")){
                    int now_row_num=Integer.parseInt(jObject.getString("new_row_num"))-1;
                    productList.add(new productData(Integer.toString(now_row_num),jObject.getString("PRODUCT_NAME"),jObject.getString("PRODUCT_PRICE"),jObject.getString("path")));
                    adapter.notifyDataSetChanged();
                }
                else if(result.equals("NoData")){
                    Toast.makeText(productListActivity.this, "End", Toast.LENGTH_SHORT).show();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };
//////////////////////////////////////////////////////////////////////////////////




    ////////////////////////////////////////////////////////////////////////////////////////////////////////

    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
  /*          int what = msg.what;*/
            value++;

            if(value < 2){
                int pgbColor = getResources().getColor(R.color.black_500);
                pgbar.setIndeterminate(true);
                pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);
                pgbar.setVisibility(View.VISIBLE);
                handler.sendEmptyMessageDelayed(0, 1000);
            }
            else if(value==2){
                handler.removeMessages(0);

                pgbar.setVisibility(View.INVISIBLE);
                newLoadChk=true;
                value=0;
            }
        }
    };

/*
handler.sendEmptyMessageDelayed(0,1000);
*/

    @SuppressLint("HandlerLeak")
    Handler handler_click = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            /*          int what = msg.what;*/
            click_value++;

            if(click_value < 1.5){
                int pgbColor = getResources().getColor(R.color.black_200);
                pgbar.setIndeterminate(true);
                pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);
                pgbar.setVisibility(View.VISIBLE);
                handler_click.sendEmptyMessageDelayed(0, 700);
            }
            else if(click_value>1.5){
                handler_click.removeMessages(0);
                int pgbColor = getResources().getColor(R.color.black_500);
                pgbar.setIndeterminate(true);
                pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);
                pgbar.setVisibility(View.INVISIBLE);
                newLoadChk_click=true;
                click_value=0;

                startActivity(intent_product);
                clickAllow=true; //이건 어차피 상관없을듯
            }
        }
    };




}