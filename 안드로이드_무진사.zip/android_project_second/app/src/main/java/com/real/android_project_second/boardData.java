package com.real.android_project_second;

public class boardData {

    int idx;
    int board_img;
    String board_name;

    public boardData(int idx, int board_img, String board_name) {
        this.idx = idx;
        this.board_img = board_img;
        this.board_name = board_name;
    }
}
