package com.real.android_project_second;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.net.URISyntaxException;

public class paymentCheckActivity extends AppCompatActivity {

    WebView mWebView;

    String user_id;
    String user_name;
    String user_address;
    String user_productlist;
    int total;
    String length;
    String[] lenArr;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_check);

        Intent getIntent=getIntent();
        user_id=getIntent.getStringExtra("user_id");
        user_name=getIntent.getStringExtra("user_name");
        user_address=getIntent.getStringExtra("user_address");
        user_productlist=getIntent.getStringExtra("user_productlist");

        Log.d("aa","user_productlist : "+ user_productlist);

        total=Integer.parseInt(getIntent.getStringExtra("total"));
        length = getIntent.getStringExtra("product_idxList");
        lenArr = length.split("_");
//        Log.d("aa","-->"+lenArr.length);
//        Log.d("aa","-->"+lenArr[0]);lek!
        
//        Log.d("aa","-->"+lenArr[1]);
//        Log.d("aa",">>"+user_id+" "+user_name+" "+user_address+" "+total);
        mWebView = (WebView)findViewById(R.id.payWebView);
        mWebView.getSettings().setJavaScriptEnabled(true);
        String url= ipToken.ipToken+"myAndroid_server/pay/paymentPage.jsp?id="+user_id+"&name="+user_name+"&address="+user_address+"&total="+total+"&user_productlist="+user_productlist;
//        String idxUrl="";
//        for(int i = 1 ; i<lenArr.length;i++){
//            idxUrl=idxUrl+"&idx_"+lenArr[i]+"="+lenArr[i];
//        }

//        Log.d("aa","url->>"+idxUrl);

        url=url+"&lenArr="+length;
        mWebView.loadUrl(url);
        mWebView.setWebViewClient(new farmWebViewClient());


    }



    private class farmWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url != null && url.startsWith("intent://")) {
                try {
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    Intent existPackage = getPackageManager().getLaunchIntentForPackage(intent.getPackage());
                    if (existPackage != null) {
                        startActivity(intent);
                    } else {
                        Intent marketIntent = new Intent(Intent.ACTION_VIEW);
                        marketIntent.setData(Uri.parse("market://details?id=" + intent.getPackage()));
                        startActivity(marketIntent);
                    }
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (url != null && url.startsWith("market://")) {
                try {
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    if (intent != null) {
                        startActivity(intent);
                    }
                    return true;
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
            }
            view.loadUrl(url);
            return false;
        }
    }



}