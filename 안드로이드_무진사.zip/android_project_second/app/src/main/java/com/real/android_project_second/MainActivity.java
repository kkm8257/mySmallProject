package com.real.android_project_second;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity   {

    EditText etId;
    EditText etPw;

    String id;


    Button btJoin;
    Button btLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etId=findViewById(R.id.et_id);
        etPw=findViewById(R.id.et_pw);

        btJoin=findViewById(R.id.bt_join);
        btLogin=findViewById(R.id.bt_login);

        btJoin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(MainActivity.this,com.real.android_project_second.joinActivity.class);
                startActivity(intent);


            }
        });

        btLogin.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                if(checkBlank()){
                    /** post **/
                    RequestQueue stringRequest = Volley.newRequestQueue(MainActivity.this);
                    String url = ipToken.ipToken+"myAndroid_server/loginServlet_url";

                    Log.d("aa","come");

                    StringRequest myReq = new StringRequest(Request.Method.POST, url,
                            successListener, errorListener) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> params = new HashMap<String, String>();

                            id = etId.getText().toString().trim();
                            String pw = etPw.getText().toString().trim();

                            Log.d("aa","id "+id);
                            Log.d("aa","pw "+pw);

                            params.put("input_id", id);
                            params.put("input_pwd", pw);

                            return params;
                        }
                    };
                    myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
                    );
                    stringRequest.add(myReq);


                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                    builder.setTitle("오류").setMessage("공백을 입력하지마세요.");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int id)
                        {
                            Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_SHORT).show();
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }


            }
        });


    }

    public boolean checkBlank(){

        boolean check=true;

        if(etId.getText().toString().trim().length()<1){
            check=false;
        }
        else if(etPw.getText().toString().trim().length()<1){
            check=false;
        }

        return check;

    }

    Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            try {
                JSONObject jObject = new JSONObject(response);
                String result= jObject.getString("result");
                if(result.equals("OK")){
                    Log.d("aa","로그인성공");

                    String token= jObject.getString("token");

                    loginToken.token=token;

                    Intent intent = new Intent(MainActivity.this,com.real.android_project_second.boardActivity.class);
                    startActivity(intent);
                    finish();

                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                    builder.setTitle("오류").setMessage("아이디가 존재하지 않습니다.");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int id)
                        {
                            Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_SHORT).show();
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };



}