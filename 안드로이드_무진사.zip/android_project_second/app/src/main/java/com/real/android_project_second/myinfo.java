package com.real.android_project_second;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class myinfo extends AppCompatActivity {

    TextView myinfo_name;
    TextView myinfo_id;
    TextView myinfo_joindate;
    TextView myinfo_address;
    Button btn_address;
    Button btn_my_cart;
    String newAddr;

    ListView delivery_info;
    ArrayList<deliveryData> deliveryList;
    deliveryAdapter deliveryApt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myinfo);
        btn_my_cart = findViewById(R.id.btn_my_cart);

        deliveryList = new ArrayList<deliveryData>();
        delivery_info = findViewById(R.id.delivery_info);

        Log.d("aa", "넘어온 토큰 : " + loginToken.token);

        deliveryApt = new deliveryAdapter(this);
        delivery_info.setAdapter(deliveryApt);


        init();


        myinfo_name = findViewById(R.id.myinfo_name);
        myinfo_id = findViewById(R.id.myinfo_id);
        myinfo_joindate = findViewById(R.id.myinfo_joindate);
        myinfo_address = findViewById(R.id.myinfo_address);
        btn_address = findViewById(R.id.btn_address);
        delivery_info = findViewById(R.id.delivery_info);

        btn_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder ad = new AlertDialog.Builder(myinfo.this);
                ad.setTitle("주소 등록");       // 제목 설정
                ad.setMessage("주소지를 입력해주세요");   // 내용 설정

                final EditText et = new EditText(myinfo.this);
                ad.setView(et);

                ad.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Text 값 받아서 로그 남기기
                        newAddr = et.getText().toString();
                        inputAddress();
                        dialog.dismiss();     //닫기
                    }
                });
                // 취소 버튼 설정
                ad.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();     //닫기
                    }
                });

                ad.show();

            }
        });

        btn_my_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(myinfo.this, com.real.android_project_second.cartListActivity.class);
                startActivity(intent);

            }
        });

    }

////////////////////////////////////////////////////////////////////////////////////////////////////////


    public void init() {
        //product kinds로 참조
        /** post **/
        RequestQueue stringRequest = Volley.newRequestQueue(this);
        String url = ipToken.ipToken + "myAndroid_server/getUserInfoServlet_url";

        StringRequest myReq = new StringRequest(Request.Method.POST, url,
                successListener_init, errorListener_init) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("token", loginToken.token);

                return params;
            }
        };
        myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
        );
        stringRequest.add(myReq);

    }

    Response.ErrorListener errorListener_init = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_init = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "init() 통신성공");

            try {
                JSONObject jObject = new JSONObject(response);


                myinfo_name.setText(jObject.getString("name"));
                myinfo_id.setText(jObject.getString("id"));
                String[] dateStr = jObject.getString("joindate").split("\\s");  //날짜부분만 절삭
                myinfo_joindate.setText("가입일  " + dateStr[0]);

                if (jObject.getString("address").equals("null")) {
                    myinfo_address.setText("주소지를 등록해주세요.");
                } else {
                    myinfo_address.setText(jObject.getString("address"));
                }
                int delListLength = Integer.parseInt(jObject.getString("productlist_length"));
                Log.d("aa", "len : " + delListLength);

                for (int i = 0; i < delListLength; i++) {

                    //배송내역
                    String productIdx="productIdx_"+i;
                    String productItem = "productItem_" + i;
                    String productArrival = "productArrival_" + i;

                    deliveryList.add(new deliveryData(jObject.getString(productIdx), jObject.getString(productItem), jObject.getString(productArrival)+" 도착"));
                    deliveryApt.notifyDataSetChanged();

                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };

////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void inputAddress() {
        //product kinds로 참조
        /** post **/
        RequestQueue stringRequest = Volley.newRequestQueue(this);
        String url = ipToken.ipToken + "myAndroid_server/setUserAddressServlet_url";

        StringRequest myReq = new StringRequest(Request.Method.POST, url,
                successListener_inputAddress, errorListener_inputAddress) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("token", loginToken.token);
                params.put("address", newAddr);

                return params;
            }
        };
        myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
        );
        stringRequest.add(myReq);

    }

    Response.ErrorListener errorListener_inputAddress = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_inputAddress = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "init() 통신성공");

            try {
                JSONObject jObject = new JSONObject(response);

                if (jObject.getString("result").equals("OK")) {
                    myinfo_address.setText(newAddr);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };

///////////////////////////////////////////////////////////

    class deliveryHolder {
        TextView custom_delivery_product_idx_holder;
        TextView custom_delivery_item_holder;
        TextView custom_delivery_arrival_holder;

    }

    class deliveryAdapter extends ArrayAdapter {
        LayoutInflater lnf;

        public deliveryAdapter(Activity context) {
            super(context, R.layout.activity_custom_delivery_item, deliveryList);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return deliveryList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return deliveryList.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }


        public View getView(int position, View convertView, ViewGroup parent) {
            deliveryHolder viewHolder;
            if (convertView == null) {

                convertView = lnf.inflate(R.layout.activity_custom_delivery_item, parent, false);
                viewHolder = new deliveryHolder();

                viewHolder.custom_delivery_product_idx_holder = convertView.findViewById(R.id.custom_delivery_product_idx);
                viewHolder.custom_delivery_item_holder = convertView.findViewById(R.id.custom_delivery_item);
                viewHolder.custom_delivery_arrival_holder = convertView.findViewById(R.id.custom_delivery_arrival);

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (deliveryHolder) convertView.getTag();
            }

            viewHolder.custom_delivery_product_idx_holder.setText(deliveryList.get(position). productIdx);
            viewHolder.custom_delivery_item_holder.setText(deliveryList.get(position).productItem);
            viewHolder.custom_delivery_arrival_holder.setText(deliveryList.get(position).productArrival);

            return convertView;
        }


    }


}