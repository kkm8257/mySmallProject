package com.real.android_project_second;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class productInfo extends AppCompatActivity {

    String kinds;
    String row;

    String product_name;
    String product_price;
    String product_imgpath;

    ImageView product_info_img;
    TextView product_info_name;
    TextView product_info_price;

    Button product_info_cart_btn;
    Button btn_my_info;
    Button btn_my_cart;

    String path;
    String product_idx;
    ProgressBar pgbar;

    int click_value=0;
    boolean clickAllow=true;
    boolean newLoadChk_click=true;

    Spinner spinner_field ;

    String size;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_info);


        spinner_field=findViewById(R.id.spinner_field);
        String[] str = new String[]{"사이즈","S","M","L"};
        final ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,R.layout.spinner_item,str);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner_field.setAdapter(adapter);

        //spinner 이벤트 리스너

        spinner_field.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(spinner_field.getSelectedItemPosition() > 0){

                    //선택된 항목

                    Log.d("aa",spinner_field.getSelectedItem().toString()+ "is selected");
                    size=spinner_field.getSelectedItem().toString();
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                    ///
            }

        });



        spinner_field = findViewById(R.id.spinner_field);
        btn_my_info=findViewById(R.id.btn_my_info);
        btn_my_cart=findViewById(R.id.btn_my_cart);

        pgbar=findViewById(R.id.pgbar);
        int pgbColor = getResources().getColor(R.color.black_500);
        pgbar.setIndeterminate(true);
        pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);




        btn_my_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(productInfo.this,com.real.android_project_second.myinfo.class);
                startActivity(intent);

            }
        });

        btn_my_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(productInfo.this,com.real.android_project_second.cartListActivity.class);
                startActivity(intent);

            }
        });
        Intent getintent = getIntent();
        kinds=getintent.getStringExtra("kind");
        row= getintent.getStringExtra("row");

        Log.d("aa","-->"+row);

        product_info_img=findViewById(R.id.product_info_img);
        product_info_name=findViewById(R.id.product_info_name);
        product_info_price=findViewById(R.id.product_info_price);
        product_info_cart_btn=findViewById(R.id.product_info_cart_btn);

        init();


        product_info_cart_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(clickAllow){
                    if(spinner_field.getSelectedItem().toString().equals("사이즈")){
                        Toast.makeText(productInfo.this, "사이즈를 선택하세요", Toast.LENGTH_SHORT).show();
                    }else{
                        handler_click.sendEmptyMessageDelayed(0, 700);
                        clickAllow=false;
                    }

                }


            }
        });



    }

    public void init(){
        //product kinds로 참조
        /** post **/
        RequestQueue stringRequest = Volley.newRequestQueue(this);
        String url = ipToken.ipToken+"myAndroid_server/productInfoServlet_url";

        StringRequest myReq = new StringRequest(Request.Method.POST, url,
                successListener_init, errorListener_init) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                Log.d("aa","request kinds >>"+kinds);
                params.put("kinds", kinds);
                params.put("row", row);
                return params;
            }
        };
        myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
        );
        stringRequest.add(myReq);

    }

    Response.ErrorListener errorListener_init = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_init = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "init 통신성공");

            try {
                JSONObject jObject = new JSONObject(response);


                product_name=jObject.getString("PRODUCT_NAME");
                product_price=jObject.getString("PRODUCT_PRICE");
                product_idx=jObject.getString("PRODUCT_IDX");

                product_imgpath=jObject.getString("path");

                product_info_name.setText(product_name);
                product_info_price.setText(product_price);
                path=product_imgpath;
                Log.d("aa",">>"+path);
                Glide.with(productInfo.this).load(path).into(product_info_img);
//



            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };



    public void cart_click(){
        //product kinds로 참조
        /** post **/
        RequestQueue stringRequest = Volley.newRequestQueue(this);
        String url = ipToken.ipToken+"myAndroid_server/productCartServlet_url";

        StringRequest myReq = new StringRequest(Request.Method.POST, url,
                successListener_cart_click, errorListener_cart_click) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("product_idx", product_idx);
                params.put("token",loginToken.token);
                params.put("size",size);
                return params;
            }
        };
        myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
        );
        stringRequest.add(myReq);

    }

    Response.ErrorListener errorListener_cart_click = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_cart_click = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "init() 통신성공");

            try {
                JSONObject jObject = new JSONObject(response);
                String Cartresult=jObject.getString("result");

                if(Cartresult.equals("OK")){
                    Toast.makeText(productInfo.this, "장바구니에 담겼습니다.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(productInfo.this, "장바구니 오류", Toast.LENGTH_SHORT).show();
                }


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };

    @SuppressLint("HandlerLeak")
    Handler handler_click = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            /*          int what = msg.what;*/
            click_value++;

            if(click_value < 1.5){
                int pgbColor = getResources().getColor(R.color.black_200);
                pgbar.setIndeterminate(true);
                pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);
                pgbar.setVisibility(View.VISIBLE);
                handler_click.sendEmptyMessageDelayed(0, 700);
            }
            else if(click_value>1.5){
                handler_click.removeMessages(0);
                int pgbColor = getResources().getColor(R.color.black_500);
                pgbar.setIndeterminate(true);
                pgbar.getIndeterminateDrawable().setColorFilter(pgbColor, PorterDuff.Mode.MULTIPLY);
                pgbar.setVisibility(View.INVISIBLE);
                newLoadChk_click=true;
                click_value=0;
                cart_click();
                clickAllow=true; //이건 어차피 상관없을듯
            }
        }
    };



}