package com.real.android_project_second;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class paymentActivity extends AppCompatActivity {


    ArrayList<cartData> cartList;
    String[] lenArr;

    paymentAdapter payAdapter;
    ListView payListView;

    Button pay_btn;
    TextView total_price;
    int total;

    TextView payment_user_id;
    EditText payment_receiver;
    TextView payment_address;

    String user_id;
    String user_name;
    String user_address;
    String user_productlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        payListView=findViewById(R.id.payment_list);
        pay_btn=findViewById(R.id.pay_btn);
        total_price=findViewById(R.id.total_price);
        payment_user_id=findViewById(R.id.payment_user_id);
        payment_receiver=findViewById(R.id.payment_receiver);
        payment_address=findViewById(R.id.payment_address);


        cartList = new ArrayList<>();
        Intent getIntent = getIntent();
        String length = getIntent.getStringExtra("cart_count");
        Log.d("aa", "len ->" + length);

        lenArr = length.split("_"); //0번쨰는 공백

        request_payment_Init();
        payAdapter=new paymentAdapter(this); //안에넣어봤음
        payListView.setAdapter(payAdapter);
        payAdapter.notifyDataSetChanged();


        pay_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {


                if(payment_address.getText().toString().equals("주소를 입력해주세요.")){
                    Toast.makeText(paymentActivity.this, "내 정보에서 주소를 기입해주세요.", Toast.LENGTH_SHORT).show();

                }else{
                    Intent intent = new Intent(paymentActivity.this,com.real.android_project_second.paymentCheckActivity.class);
                    intent.putExtra("user_id",user_id);
                    intent.putExtra("user_name",user_name);
                    intent.putExtra("user_address",user_address);
                    intent.putExtra("total",Integer.toString(total));
                    intent.putExtra("user_productlist",user_productlist);
                    //유저아이디랑
                    //받는사람 (name)
                    //주소
                    //가격   전달달
                    for(int i = 0 ;i<cartList.size();i++){
                        String product_idx=Integer.toString(cartList.get(i).idx);
                        intent.putExtra("product_idx_"+product_idx,product_idx);  //결제할 제품 번호 intent에 각각 넘겨주기
                    }
                    intent.putExtra("product_idxList",length); //idx 일렬로 담긴 값


                    startActivity(intent);
                    finish();
                }


            }
        });


    }
    ////////////////////////////////////////////////////



    ////////////////////////////////////////////////////

    public void request_payment_Init() {
        //product kinds로 참조
        /** post **/
        RequestQueue stringRequest = Volley.newRequestQueue(this);
        String url = ipToken.ipToken+"myAndroid_server/paymentServlet_url";

        StringRequest myReq = new StringRequest(Request.Method.POST, url,
                successListener_payment_Init, errorListener_payment_Init) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                String idxLength = Integer.toString(lenArr.length - 1);

                params.put("length", idxLength);
                for (int i = 0; i < lenArr.length - 1; i++) {
                    String str_idx = "idx_" + i;
                    params.put(str_idx, lenArr[i + 1]);
                }

                params.put("token",loginToken.token);

                return params;
            }
        };
        myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
        );
        stringRequest.add(myReq);

    }

    Response.ErrorListener errorListener_payment_Init = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_payment_Init = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "통신성공");


            try {
                JSONObject jObject = new JSONObject(response);


                for(int i  = 1 ;i<lenArr.length;i++){


                    int idx=Integer.parseInt(jObject.getString("cart_idx_"+lenArr[i]));
                    String name=jObject.getString("cart_"+lenArr[i]+"_name");
                    int price=Integer.parseInt(jObject.getString("cart_"+lenArr[i]+"_price"));
                    String img=jObject.getString("cart_"+lenArr[i]+"_img");
                    int count=Integer.parseInt(jObject.getString("cart_"+lenArr[i]+"_count"));
                    String kinds=jObject.getString("cart_"+lenArr[i]+"_kinds");
                    String path=ipToken.ipToken+"myAndroid_server/storage/";

                    String size=jObject.getString("cart_"+lenArr[i]+"_size");
                    Log.d("aa","size : "+size);

                    path=path+kinds+"/";
                    path=path+img;
                    cartList.add(new cartData(idx,false,name,price,path,count,size));  //check값은 그냥 false로 줌
                    payAdapter.notifyDataSetChanged();

                    total=total+(count*price);
                    total_price.setText(Integer.toString(total));
                }

                user_id=jObject.getString("user_id");
                user_name=jObject.getString("user_name");
                user_address=jObject.getString("user_address");
                user_productlist=jObject.getString("user_productlist");

                payment_user_id.setText(user_id);
                payment_receiver.setText(user_name);
                if(user_address.equals("null")){
                    payment_address.setText("주소를 입력해주세요.");
                }
                else{
                    payment_address.setText(user_address);
                }

//                for (int i = 0 ; i<cartList.size();i++){
//                    Log.d("aa",">>"+cartList.get(i).idx);
//                    Log.d("aa",">>"+cartList.get(i).name);
//                    Log.d("aa",">>"+cartList.get(i).price);
//                    Log.d("aa",">>"+cartList.get(i).count);
//                    Log.d("aa",">>"+cartList.get(i).img);
//                    Log.d("aa","----------------------------------");
//
//                }





            } catch (JSONException e) {
                e.printStackTrace();
            }


        }


    };

    ////////////////////////////////////////////////////////////////////////////////////////


    class paymentHolder{
        ImageView custom_payment_img_holder;
        TextView custom_payment_name_holder;
        TextView custom_payment_price_holder;
        TextView custom_payment_count_holder;
        TextView getCustom_payment_size_holder;
    }

    class paymentAdapter extends ArrayAdapter {
        LayoutInflater lnf;

        public paymentAdapter(Activity context) {
            super(context, R.layout.activity_custom_payment_item, cartList);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return cartList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return cartList.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            paymentHolder viewHolder;
            if (convertView == null) {
                Log.d("aa","getview");
                convertView = lnf.inflate(R.layout.activity_custom_payment_item, parent, false);
                viewHolder = new paymentHolder();

                viewHolder.custom_payment_img_holder= convertView.findViewById(R.id.payment_product_img);
                viewHolder.custom_payment_name_holder = convertView.findViewById(R.id.payment_name);
                viewHolder.custom_payment_price_holder = convertView.findViewById(R.id.payment_price);
                viewHolder.custom_payment_count_holder = convertView.findViewById(R.id.payment_count);
                viewHolder.getCustom_payment_size_holder=convertView.findViewById(R.id.payment_size);

                convertView.setTag(viewHolder);
            } else {
                viewHolder = (paymentHolder) convertView.getTag();
            }





            Glide.with(paymentActivity.this).load(cartList.get(position).img).into(viewHolder.custom_payment_img_holder);
            viewHolder.custom_payment_name_holder.setText(cartList.get(position).name);
            viewHolder.custom_payment_price_holder.setText(Integer.toString(cartList.get(position).price));
            viewHolder.custom_payment_count_holder.setText(Integer.toString(cartList.get(position).count));
            viewHolder.getCustom_payment_size_holder.setText(cartList.get(position).size);
            return convertView;
        }
    }



    ////////////////////////////////////////////////////////////////////////////////////////
}