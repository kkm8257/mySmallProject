package com.real.android_project_second;

public class loginToken {
    public static String token="";

}
