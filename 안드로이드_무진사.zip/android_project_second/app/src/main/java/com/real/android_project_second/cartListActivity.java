package com.real.android_project_second;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class cartListActivity extends AppCompatActivity {

    ListView cartlistView;
    cartAdapter cartadapter;

    ArrayList<cartData> cartList;

    Button cart_payment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_list);
        cartlistView=findViewById(R.id.cart_list);
        cart_payment=findViewById(R.id.cart_payment);

        cartList=new ArrayList<>();
        request_cart_Init();
        cartadapter=new cartAdapter(this);
        cartlistView.setAdapter(cartadapter);
        //토큰값으로 아이디를 조회하고 , 그 아이디의 카트 테이블 리스트를 뽑아오자
        cartadapter.notifyDataSetChanged();


        cart_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(cartListActivity.this,com.real.android_project_second.paymentActivity.class);
                String count_idx = "" ;
                for(int i = 0 ; i<cartList.size();i++){
                    if(cartList.get(i).isChecked){
                        int idx=cartList.get(i).idx;
                        String cart_idx ="cart_idx_"+Integer.toString(idx);
                        String cart_name=cart_idx+"_"+cartList.get(i).name;
                        String cart_price=cart_idx+"_"+Integer.toString(cartList.get(i).price);
                        String cart_count=cart_idx+"_"+Integer.toString(cartList.get(i).count);
                        intent.putExtra(cart_name,cart_name);
                        intent.putExtra(cart_price,cart_price);
                        intent.putExtra(cart_count,cart_count);
                        count_idx=count_idx+"_"+idx;
                    }
                }

                intent.putExtra("cart_count",count_idx);

                if(count_idx.equals("")){
                    Toast.makeText(cartListActivity.this, "결제하실 상품을 선택해주세요", Toast.LENGTH_SHORT).show();
                }
                else{
                    startActivity(intent);
                }

            }
        });


    }

    ///////////////////////////////////////////////////

    class cartHolder{
        CheckBox custom_cart_check_holder;
        ImageView custom_cart_img_holder;
        TextView custom_cart_name_holder;
        TextView custom_cart_price_holder;
        TextView custom_cart_count_holder;
        TextView custom_cart_size_holder;
    }

    class cartAdapter extends ArrayAdapter {
        LayoutInflater lnf;

        public cartAdapter(Activity context) {
            super(context, R.layout.activity_custom_cart_item, cartList);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return cartList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return cartList.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            cartHolder viewHolder;
            if (convertView == null) {

                convertView = lnf.inflate(R.layout.activity_custom_cart_item, parent, false);
                viewHolder = new cartHolder();

                viewHolder.custom_cart_check_holder=convertView.findViewById(R.id.cart_check_box);
                viewHolder.custom_cart_img_holder= convertView.findViewById(R.id.cart_product_img);
                viewHolder.custom_cart_name_holder = convertView.findViewById(R.id.cart_name);
                viewHolder.custom_cart_price_holder = convertView.findViewById(R.id.cart_price);
                viewHolder.custom_cart_count_holder = convertView.findViewById(R.id.cart_count);
                viewHolder.custom_cart_size_holder=convertView.findViewById(R.id.cart_size);



                convertView.setTag(viewHolder);
            } else {
                viewHolder = (cartHolder) convertView.getTag();
            }



            if(viewHolder.custom_cart_check_holder.isChecked()){
                viewHolder.custom_cart_check_holder.setChecked(false);
            }

            viewHolder.custom_cart_check_holder.setOnClickListener(new CheckBox.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if(cartList.get(position).isChecked){
                        cartList.get(position).isChecked=false;
                    }
                    else{
                        cartList.get(position).isChecked=true;

                    }
                }
            }) ;

            Log.d("aa",">a>"+cartList.get(position).img);

            Glide.with(cartListActivity.this).load(cartList.get(position).img).into(viewHolder.custom_cart_img_holder);
            viewHolder.custom_cart_name_holder.setText(cartList.get(position).name);
            viewHolder.custom_cart_price_holder.setText(Integer.toString(cartList.get(position).price));
            viewHolder.custom_cart_count_holder.setText(Integer.toString(cartList.get(position).count));
            viewHolder.custom_cart_size_holder.setText(cartList.get(position).size);
            return convertView;
        }
    }


////////////////////////////////////////////////////////////////////////////////////
public void request_cart_Init(){
    //product kinds로 참조
    /** post **/
    RequestQueue stringRequest = Volley.newRequestQueue(this);
    String url = ipToken.ipToken+"myAndroid_server/myCartListServlet_url";

    StringRequest myReq = new StringRequest(Request.Method.POST, url,
            successListener_cart_Init, errorListener_cart_Init) {
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            Map<String, String> params = new HashMap<String, String>();

            params.put("token", loginToken.token);

            return params;
        }
    };
    myReq.setRetryPolicy(new DefaultRetryPolicy(3000, 0, 1f)
    );
    stringRequest.add(myReq);

}

    Response.ErrorListener errorListener_cart_Init = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {

            Log.d("aa", "통신실패");
        }
    };

    Response.Listener<String> successListener_cart_Init = new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {

            Log.d("aa", "통신성공");


            try {
                JSONObject jObject = new JSONObject(response);
                int listSize=Integer.parseInt(jObject.getString("listSize"));
                Log.d("aa","size : "+listSize);
                if(listSize>0){
                    for(int i = 0 ; i<listSize;i++){
                        boolean isChk=false;

                        int idx=Integer.parseInt(jObject.getString("cart_idx_"+Integer.toString(i)));
//                        Log.d("aa","----------------idx >>"+idx);
                        String name=jObject.getString("cart_"+Integer.toString(i)+"_name");
                        int price=Integer.parseInt(jObject.getString("cart_"+Integer.toString(i)+"_price"));
                        String img=jObject.getString("cart_"+Integer.toString(i)+"_img");
                        int count=Integer.parseInt(jObject.getString("cart_"+Integer.toString(i)+"_count"));
                        String kinds= jObject.getString("cart_"+Integer.toString(i)+"_kinds");
                        String path=ipToken.ipToken+"myAndroid_server/storage/";
                        path=path+kinds+"/";
                        path=path+img;

                        String size=jObject.getString("cart_"+Integer.toString(i)+"_size");


                        cartList.add(new cartData(idx,isChk,name,price,path,count,size));
                        cartadapter.notifyDataSetChanged();
                    }

                }
                else{
                    
                    Log.d("aa","카트가비었음");
                    
                }
             


            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };

////////////////////////////////////////////////////////////////////////





}