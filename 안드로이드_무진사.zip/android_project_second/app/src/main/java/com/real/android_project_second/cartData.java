package com.real.android_project_second;

public class cartData {

    int idx;
    boolean isChecked;
    String name ;
    int price;
    String img;
    int count;
    String size;
//    String kinds; //kinds는 생성자에 추가안함

    public cartData(int idx, boolean isChecked, String name, int price, String img, int count) {
        this.idx = idx;
        this.isChecked = isChecked;
        this.name = name;
        this.price = price;
        this.img = img;
        this.count = count;
    }



    public cartData(int idx, boolean isChecked, String name, int price, String img, int count,String size) {
        this.idx = idx;
        this.isChecked = isChecked;
        this.name = name;
        this.price = price;
        this.img = img;
        this.count = count;
        this.size= size;
    }
}
