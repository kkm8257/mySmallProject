package com.real.android_project_second;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class boardActivity extends AppCompatActivity {

    ViewFlipper viewFlipper;
    ImageView board_1;
    ImageView board_2;
    ImageView board_3;


    Button btn_my_info;
    Button btn_my_cart;

    boardAdapter boardMyAdapter;
    ListView board_list_view;
    ArrayList<boardData> boardList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);
        Log.d("aa", "넘어온 토큰 : " + loginToken.token);

        viewFlipper=findViewById(R.id.viewFlipper);
        board_1=findViewById(R.id.ad_image_1);
        board_2=findViewById(R.id.ad_image_2);
        board_3=findViewById(R.id.ad_image_3);

        viewFlipper.startFlipping();
        viewFlipper.setFlipInterval(2300);


        board_list_view=findViewById(R.id.board_list_view);

        boardList.add(new boardData(0,R.drawable.outer_main,"outer"));
        boardList.add(new boardData(1,R.drawable.top_main,"top"));
        boardList.add(new boardData(2,R.drawable.bottom_main,"bottom"));
        boardList.add(new boardData(3,R.drawable.shoes_main,"shoes"));
        boardList.add(new boardData(4,R.drawable.acc_main,"acc"));
        boardList.add(new boardData(5,R.drawable.watch_main,"watch"));
        boardList.add(new boardData(6,R.drawable.glasses_main,"glasses"));


        boardMyAdapter=new boardAdapter(this);
        board_list_view.setAdapter(boardMyAdapter);


        btn_my_info=findViewById(R.id.btn_my_info);
        btn_my_cart=findViewById(R.id.btn_my_cart);

        btn_my_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(boardActivity.this,com.real.android_project_second.myinfo.class);
                startActivity(intent);
            }
        });

        btn_my_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(boardActivity.this,com.real.android_project_second.cartListActivity.class);
                startActivity(intent);

            }
        });



        board_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent;
                intent = new Intent( boardActivity.this,com.real.android_project_second.productListActivity.class);
                intent.putExtra("kind", boardList.get(position).board_name);
                startActivity(intent);
//                Toast.makeText(boardActivity.this, "kinds : "+boardList.get(position).board_name, Toast.LENGTH_SHORT).show();

            }
        });

    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    class boardHolder{
        ImageView custom_board_img_holder;
        TextView custom_board_name_holder;
    }

    class boardAdapter extends ArrayAdapter{
        LayoutInflater lnf;

    public boardAdapter(Activity context){
        super(context,R.layout.activity_custom_board_item,boardList);
        lnf = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return boardList.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return boardList.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }


        public View getView(int position, View convertView, ViewGroup parent) {
            boardHolder viewHolder;
            if (convertView == null) {

                convertView = lnf.inflate(R.layout.activity_custom_board_item, parent, false);
                viewHolder = new boardHolder();

                viewHolder.custom_board_img_holder = convertView.findViewById(R.id.custom_board_img);
                viewHolder.custom_board_name_holder = convertView.findViewById(R.id.custom_board_name);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (boardHolder) convertView.getTag();
            }

            viewHolder.custom_board_img_holder.setImageResource(boardList.get(position).board_img);
            viewHolder.custom_board_name_holder.setText(boardList.get(position).board_name);

            return convertView;
        }



    }

    



}
