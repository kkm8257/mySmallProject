package com.real.android_project_second;

public class deliveryData {

    String productIdx;
    String productItem;
    String productArrival;

    public deliveryData(String productIdx, String productItem, String productArrival) {
        this.productIdx = productIdx;
        this.productItem = productItem;
        this.productArrival = productArrival;
    }
}
