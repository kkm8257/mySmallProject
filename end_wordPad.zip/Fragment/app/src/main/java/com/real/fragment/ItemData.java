package com.real.fragment;

public class ItemData {


    String eng;
    String kor;


    public ItemData(String eng, String kor) {
        this.eng = eng;
        this.kor = kor;
    }
}
