package com.real.fragment;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class fragment_test_activity extends Fragment {

    fragment_home_activity fragHome;

    int count = 0;
    int score = 0;

    TextView timer;
    Button back_btn;
    Button submit_btn;
    Button swap_btn;

    int timer_Count = 6;

    boolean isEnd;

    boolean isSwap = false;
    View layout;
    ArrayList<ItemData> arrBackUp = new ArrayList<>();

    public fragment_test_activity newInstance() {
        return new fragment_test_activity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        layout = inflater.inflate(R.layout.frag_test, container, false);

        fragHome = new fragment_home_activity();
        back_btn = layout.findViewById(R.id.back_btn);
        submit_btn = layout.findViewById(R.id.submit_btn);
        swap_btn = layout.findViewById(R.id.swap_btn);
        timer=layout.findViewById(R.id.timer);



        handler.sendEmptyMessageDelayed(0,0);


        resetMyVoca();


        Log.d("aabb", "size : " + arrBackUp.size());

        if (arrBackUp.size() != 0) {
            timer.setVisibility(View.VISIBLE);
            ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(0).eng);
            ((EditText) layout.findViewById(R.id.answer_et)).setVisibility(View.VISIBLE);

        } else {
            ((TextView) layout.findViewById(R.id.word_tv)).setText("문제가 존재하지않습니다.");
            ((EditText) layout.findViewById(R.id.answer_et)).setVisibility(View.INVISIBLE);

        }


        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((MainActivity) getActivity()).change(fragHome.newInstance());

            }
        });

        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (arrBackUp.size() != 0) {

                    String checkAns;
                    String checkQuiz;

                    String nextQuiz;
                    String Ans;


                    checkAns = ((EditText) layout.findViewById(R.id.answer_et)).getText().toString();
                    Log.d("aabb", checkAns);
                    Log.d("aabb", "count : " + count);
                    Log.d("aabb", "swap -> " + isSwap);


                    if (isSwap == false) { //영어가문제
                        Ans = arrBackUp.get(count).kor;
                    } else {  //한글이문제
                        Ans = arrBackUp.get(count).eng;
                    }

                    Log.d("aabb", "입력 답 : " + checkAns);

                    Log.d("aabb", "실제 답 : " + Ans);
                    if (checkAns.equals(Ans)) {
                        Log.d("aabb", "정답");
                        Toast.makeText(getActivity(), "정답!", Toast.LENGTH_SHORT).show();
                        isEnd=true;
                        score++;
                        count++;
                    } else {
                        Toast.makeText(getActivity(), "오답!", Toast.LENGTH_SHORT).show();

                        count++;
                    }

                    if (count < arrBackUp.size()) {
                        if (isSwap == false) {
                            ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(count).eng);

                        } else {
                            ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(count).kor);

                        }

                    } else if (count == arrBackUp.size()) {

                        ((TextView) layout.findViewById(R.id.word_tv)).setVisibility(View.GONE);
                        ((EditText) layout.findViewById(R.id.answer_et)).setVisibility(View.GONE);
                        ((Button) layout.findViewById(R.id.submit_btn)).setVisibility(View.GONE);
                        ((Button) layout.findViewById(R.id.swap_btn)).setVisibility(View.GONE);

                        ((TextView) layout.findViewById(R.id.result_tv)).setText("획득점수\n" + score + "점");
                        ((TextView) layout.findViewById(R.id.result_tv)).setVisibility(View.VISIBLE);
                        timer.setVisibility(View.INVISIBLE);
                        handler.removeMessages(0);
                    }
                    ((EditText) layout.findViewById(R.id.answer_et)).setText("");


                }


            }
        });

        swap_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                isSwap = !isSwap;
                count = 0;
                score = 0;

                if (isSwap == false) {
                    Log.d("aabb", "swap -> " + isSwap);
                    ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(count).eng);
                    ((EditText) layout.findViewById(R.id.answer_et)).setText("");

                } else {
                    Log.d("aabb", "swap -> " + isSwap);
                    ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(count).kor);
                    ((EditText) layout.findViewById(R.id.answer_et)).setText("");

                }

            }
        });

        return layout;
    }


    public void resetMyVoca() {

        Cursor c = ((MainActivity) getActivity()).db.rawQuery("SELECT * FROM voca", null);

        Log.d("aabb", "count: " + c.getCount()); // 전체 줄수를 가져온다

        c.moveToFirst();
        while (c.isAfterLast() == false) {
            Log.d("aabb",
                    "eng: " + c.getString(1)
                            + " kor: " + c.getInt(2));
            arrBackUp.add(new ItemData(c.getString(1), c.getString(2)));
            c.moveToNext();
        }

        c.close();

    }


    @SuppressLint("HandlerLeak")
    android.os.Handler handler = new Handler(){

        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            if(timer_Count==-1){ //시간초과
//                Toast.makeText(getActivity(), "시간초과", Toast.LENGTH_SHORT).show();
                timer_Count=6;
                isEnd=false;

                count++;


                if (count < arrBackUp.size()) {
                    if (isSwap == false) {
                        ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(count).eng);

                    } else {
                        ((TextView) layout.findViewById(R.id.word_tv)).setText(arrBackUp.get(count).kor);

                    }

                } else if (count == arrBackUp.size()) {

                    ((TextView) layout.findViewById(R.id.word_tv)).setVisibility(View.GONE);
                    ((EditText) layout.findViewById(R.id.answer_et)).setVisibility(View.GONE);
                    ((Button) layout.findViewById(R.id.submit_btn)).setVisibility(View.GONE);
                    ((Button) layout.findViewById(R.id.swap_btn)).setVisibility(View.GONE);

                    ((TextView) layout.findViewById(R.id.result_tv)).setText("획득점수\n" + score + "점");
                    ((TextView) layout.findViewById(R.id.result_tv)).setVisibility(View.VISIBLE);
                    timer.setVisibility(View.INVISIBLE);
                    handler.removeMessages(0);
                }
                ((EditText) layout.findViewById(R.id.answer_et)).setText("");


                handler.removeMessages(0);
                handler.sendEmptyMessageDelayed(0,0);

            }

            else if(isEnd==false){  //시간이 흐른다

                timer.setText(timer_Count+"");
                timer_Count--;
                handler.sendEmptyMessageDelayed(0,1000);

            }

            else if(isEnd==true){  //맞춤

                timer_Count=6;
                isEnd=false;
                timer.setText(timer_Count+"");
                handler.removeMessages(0);
                handler.sendEmptyMessageDelayed(0,1000);
            }


        }
    };


}
