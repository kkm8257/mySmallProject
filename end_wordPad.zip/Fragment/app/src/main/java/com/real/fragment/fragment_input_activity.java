package com.real.fragment;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class fragment_input_activity extends Fragment {

    Button back_btn;
    Button input_btn;
    fragment_home_activity fragHome;

    EditText input_eng;
    EditText input_kor;

    ListView lv;
    MyAdapter adapter;
    ArrayList<ItemData> itemArr = new ArrayList<>();

    public fragment_input_activity newInstance() {

        return new fragment_input_activity();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View layout = inflater.inflate(R.layout.frag_input,container,false);

        Toast.makeText(getActivity(), "단어입력", Toast.LENGTH_SHORT).show();
        //getActivity,   즉 this를 사용할수없음 , 프레그먼트는 액티비티  보다 위에 띄워지는 개념이니까 , getActivity를 통해 내 밑에있는 액티비티의 값을 가져오는 개념

        input_btn=layout.findViewById(R.id.input_btn);
        back_btn=layout.findViewById(R.id.back_btn);
        input_eng=layout.findViewById(R.id.input_eng);
        input_kor=layout.findViewById(R.id.input_kor);


        fragHome = new fragment_home_activity();


        lv=layout.findViewById(R.id.myvoca_list);
        adapter=new MyAdapter(this.getActivity());
        lv.setAdapter(adapter);

        Log.d("aabb","길이"+itemArr.size()); //메소드를 하나만들어서 불어오는거 만들기

        resetMyVoca();
        adapter.notifyDataSetChanged();



        input_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tempEng=input_eng.getText().toString();
                String tempKor=input_kor.getText().toString();

                ((MainActivity)getActivity()).db_insert(tempEng,tempKor);
                adapter.add(new ItemData(tempEng,tempKor));
                adapter.notifyDataSetChanged();

                input_eng.setText("");
                input_kor.setText("");




            }
        });

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((MainActivity)getActivity()).change(fragHome.newInstance());
            }
        });

        return layout;
    }


    public void resetMyVoca(){

        Cursor c = ((MainActivity)getActivity()).db.rawQuery("SELECT * FROM voca", null);

        Log.d("aabb", "count: " + c.getCount()); // 전체 줄수를 가져온다

        c.moveToFirst();
        while (c.isAfterLast() == false) {
            Log.d("heu",
                    "eng: " + c.getString(1)
                            + " kor: " + c.getInt(2));

            adapter.add(new ItemData(c.getString(1),c.getString(2)));

            c.moveToNext();
        }

        c.close();

    }

    class ItemHolder {
        TextView tvHolder;
        Button delBtnHolder;
    }

    class MyAdapter extends ArrayAdapter {
        LayoutInflater lnf;

        public MyAdapter(Activity context) {
            super(context, R.layout.item, itemArr);
            lnf = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return itemArr.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return itemArr.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            final ItemHolder viewHolder;
            if (convertView == null) {
                convertView = lnf.inflate(R.layout.item, parent, false);
                viewHolder = new ItemHolder();
                viewHolder.tvHolder = convertView.findViewById(R.id.text_tv);
                viewHolder.delBtnHolder=convertView.findViewById(R.id.text_delbtn);

                convertView.setTag(viewHolder);
//                Log.d("aabb","tag : "+convertView.getTag());
                //tag에는 오브젝트를 넣을수 있다.


            } else {
                viewHolder = (ItemHolder) convertView.getTag();
//                Log.d("aabb","reset->tag : "+viewHolder);

            }

            viewHolder.delBtnHolder.setTag(position);
            viewHolder.tvHolder.setText(itemArr.get(position).eng+" --- "+itemArr.get(position).kor);

            final String getEng=itemArr.get(position).eng;
            final String getKor=itemArr.get(position).kor;

            viewHolder.delBtnHolder.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = Integer.parseInt(String.valueOf(v.getTag()));
                    ((MainActivity)getActivity()).db_delete(getEng,getKor);
                    itemArr.remove(pos);
                    adapter.notifyDataSetChanged();

                }
            });



            return convertView;
        }
    }


}
