package com.real.fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

public class fragment_home_activity extends Fragment {

    Button btn_input;
    Button btn_test;
    Button btn_end;


    fragment_home_activity fragHome;
    fragment_input_activity fragInput;
    fragment_test_activity fragTest;


    //안드로이드의 프래그먼트는 파라미터가 없는 constructor 만 가지고 있다.
    //즉 생성자를 통한 값 할당 방식 사용불가


    public  fragment_home_activity newInstance() {
        //프래그먼트 재생성(화면 회전과 같은)시 빈생성자가 있어야 함

        return new fragment_home_activity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View layout = inflater.inflate(R.layout.frag_home,container,false);

        Toast.makeText(getActivity(), "start Home!!", Toast.LENGTH_SHORT).show();

        fragHome = new fragment_home_activity();
        fragInput = new fragment_input_activity();
        fragTest = new fragment_test_activity();


        btn_input=layout.findViewById(R.id.btn1);
        btn_test=layout.findViewById(R.id.btn2);
        btn_end=layout.findViewById(R.id.btn3);

        btn_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((MainActivity)getActivity()).change(fragInput.newInstance());
                //형변환이 필요한이유는 우리가 getAcitivity하면 그게 내 부모 엑티비티인 MainActivity인걸 알지만 컴퓨터는모름 , 그래서 형변환 필요
            }
        });

        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity)getActivity()).change(fragTest.newInstance());
            }
        });


        btn_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((MainActivity)getActivity()).finish();;


            }
        });


        return layout;


    }
}