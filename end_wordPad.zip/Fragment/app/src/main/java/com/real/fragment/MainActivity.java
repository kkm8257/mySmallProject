package com.real.fragment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {


    fragment_home_activity fragHome;
    fragment_input_activity fragInput;
    fragment_test_activity fragTest;

    FragmentManager fm;
    FragmentTransaction ft;

    DrawerLayout drawer;

    TextView input_tv;
    TextView test_tv;

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = openOrCreateDatabase("sqlTest3.db", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS voca(idx INTEGER PRIMARY KEY AUTOINCREMENT, eng TEXT , kor TEXT);");





        fragHome = new fragment_home_activity();
        fragInput =new fragment_input_activity();
        fragTest=new fragment_test_activity();

        drawer = findViewById(R.id.drawer_frame);

        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        ft.replace(R.id.main_act, fragHome);
        ft.commit();


        findViewById(R.id.input_word).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                drawer.closeDrawer(Gravity.LEFT);
                fm = getSupportFragmentManager();
                ft = fm.beginTransaction();
                ft.replace(R.id.main_act, fragInput);
                ft.commit();


            }
        });

        findViewById(R.id.test_word).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawer.closeDrawer(Gravity.LEFT);
                fm = getSupportFragmentManager();
                ft = fm.beginTransaction();
                ft.replace(R.id.main_act, fragTest);
                ft.commit();


            }
        });

//메인액티비티는 틀만 제공 , 버튼이나 모든것을 프레그먼트내부에 넣은경우

    }

    public void change(Fragment fragment) {

        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        ft.replace(R.id.main_act, fragment);
        ft.commit();

    }
    public void db_insert(String eng, String kor){
        String tempEng= eng;
        String tempKor=kor;

        String sql = "INSERT INTO voca(eng,kor) VALUES('"+tempEng+"','"+tempKor+"')";
        Log.d("aabb",sql);
        db.execSQL(sql);

    }

    public void db_delete(String eng, String kor){
        String tempEng= eng;
        String tempKor=kor;

        String sql = "DELETE FROM voca WHERE eng = '"+eng+"' AND kor = '"+kor+"'";
        db.execSQL(sql);


    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("종료");
        builder.setPositiveButton("종료", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alertDialog = builder.create();

        alertDialog.show();

    }

}